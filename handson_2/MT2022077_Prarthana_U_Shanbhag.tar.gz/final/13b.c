// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:the second program will send the signal (using kill system call)

#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
	if(argc<2){
	printf("Enter the processid as command line argument !!\n");
 	return -1;
	}
	int pid_to_kill = atoi(argv[1]);

	int ret = kill(pid_to_kill,SIGSTOP);
	if(ret==-1)
	{
		perror("KILL ERROR");
		return -1;
	}
	else
		printf("SENT SIGSTOP SIGNAL TO THE PROCESS %d\n",pid_to_kill);
	return 0;
}
/*
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ gcc 13b.c -o 13b.out
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./13b.out
Enter the processid as command line argument !!
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./13b.out 985
SENT SIGSTOP SIGNAL TO THE PROCESS 985
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$
*/