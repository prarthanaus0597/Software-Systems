// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write two programs so that both can communicate by FIFO -Use one way communication.

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

//reading from  fifo file 
int main(int argc,char **argv) {
char buff[50];
if(argc>2 || argc<=1){
printf("Enter only one file name as command line argument\n");

}
else{
char *arg=argv[1];
int fd = open(arg, O_RDONLY);
if(fd>0){
read(fd, buff, sizeof(buff));
printf("The text recieved from FIFO file: %s\n", buff);
}
else{
printf("no such file found \n");
}
}
return 0;
}
