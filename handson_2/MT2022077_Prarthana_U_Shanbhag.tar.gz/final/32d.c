// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to implement semaphore to protect any critical section.d) remove the created semaphore
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <unistd.h>

int main()
{	
	int semid;
	printf("Enter the ID of Semaphore you want to remove :\n");
	scanf("%d",&semid);

	int ret = semctl(semid,0,IPC_RMID);
	if(ret==-1)
	{
		perror("SEMCTL ERROR");
		return -1;
	}
	else
		printf("Semaphore with ID %d is removed successfully!!!\n",semid);
	return 0;
}


/*
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ipcs -s

------ Semaphore Arrays --------
key        semid      owner      perms      nsems
0x000022b8 0          prarthanau 666        1
0x00001a85 1          prarthanau 666        1
0x00000457 2          prarthanau 666        1

prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ gcc 32d.c
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./a.out
Enter the ID of Semaphore you want to remove :
0
Semaphore with ID 0 is removed successfully!!!
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ipcs -s

------ Semaphore Arrays --------
key        semid      owner      perms      nsems
0x00001a85 1          prarthanau 666        1
0x00000457 2          prarthanau 666        1

*/