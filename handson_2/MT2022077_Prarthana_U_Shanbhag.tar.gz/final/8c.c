// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question : Write a separate program using signal system call to catch the following signals.c) SIGFPE
//SIGFPE = Floating point exception (man 7 signal)
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>

void handler_func(int signum)
{
	if(signum==SIGFPE)
		printf("Caught Signal SIGFPE!!!\n");
	else
		printf("Invalid signal\n");
}

int main()
{
	typedef void (*sighandler_t)(int);

	signal(SIGFPE, (sighandler_t)handler_func); //to change the disposition of signal(to determine how process behaves on getting signal)
	printf("Sent Floating point exception\n");
	//Explicitly send signal to this process using kill system call
	int ret = kill(getpid(),SIGFPE);
	if(ret==-1)
	{
		perror("KILL ERROR");
		return -1;
	}
	return 0;

}