// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question : Write a separate program using signal system call to catch the following signals.f) SIGVTALRM (use setitimer system call)
//SIGVTALRM = Virtual alarm clock using setitimer()(man 7 signal)
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/time.h>

void handler_func(int signum)
{
	if(signum == SIGVTALRM)
		printf("Caught Signal SIGVTALRM!!!\n");
	else
		printf("Invalid signal\n");
}

int main()
{
	typedef void (*sighandler_t)(int);

	signal(SIGVTALRM,(sighandler_t)handler_func); //to change the disposition of signal(to determine how process behaves on getting signal)

	
	struct itimerval timer;
	timer.it_value.tv_sec =3; //seconds
	timer.it_value.tv_usec = 0; //microseconds

	//set periodic interval for timer to expire
	timer.it_interval.tv_sec =1;
	timer.it_interval.tv_usec =0;
	printf("Virtual alarm clock using setitimer() is set\n");
	setitimer(ITIMER_VIRTUAL,&timer,NULL);//set interval timer

	while(1);
	return 0;

}
