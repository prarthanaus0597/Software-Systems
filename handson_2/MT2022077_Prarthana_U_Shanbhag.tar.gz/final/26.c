// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to send messages to the message queue. Check $ipcs -q

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

//ipcrm -q id - to remove 
int main(int argc,char **argv){
if(argc<2){
printf("Enter a token for msgid as command line argument\n ");
}
else{


struct msg {
long int msg_type;
char msg_text[80];
} msg_queue;

char arg=argv[1][0];

int key = ftok(".", arg);
int msgqid = msgget(key, IPC_CREAT|0744);
if(msgqid==-1){
printf("Error while accessing Msg queue  with key %d. \n",key);
}
else{
printf("Enter message type: ");
scanf("%ld", &msg_queue.msg_type);
printf("Enter message text:");
scanf("%s", msg_queue.msg_text);
int size = strlen(msg_queue.msg_text);
// size + 1 to accommodate terminating character
msgsnd(msgqid, &msg_queue, size + 1, 0);
printf("Msg stored in msg queue \n");
}}
return 0;
}

