// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to create a message queue and print the key and message queue id.

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>


int main(int argc,char **argv){
if(argc<2){
printf("Enter a token for msgid as command line argument\n ");
}
else{

char arg=argv[1][0];
// 'a' = ASCII value of "a" given as proj_id and "." will be string used to create key
int key = ftok(".", arg);

//msgget() system call returns the System V message queue identifier associated with the value of the key argument.
int msgid = msgget(key, IPC_CREAT|IPC_EXCL|0744);	//If msgflg specifies both IPC_CREAT and IPC_EXCL and a message queue already exists for key, then msgget() fails with  errno  set  to  EEXIST.
// %0x for Hexadecimal value
if(msgid==-1){
printf("msg queue already exists with same key.Give some other token as command line argument!!\n");
}
else{
printf("key=0x%0x\t msgid=%d\n", key, msgid);
}
}
//ipcs -q to see the created queue
return 0;
}

