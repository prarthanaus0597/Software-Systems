// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question :Write a program to ignore a SIGINT signal then reset the default action of the SIGINT signal - Use signal system call.

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
	__sighandler_t signalStatus; // Determines the success of the `signal` call
	//Ignore SIGINT signal
	signalStatus=signal(SIGINT,SIG_IGN);
	if(signalStatus == SIG_ERR){
        perror("Error while trying to ignore signal!");
	}
	else{
	printf("Any interrupt from keyboard(SIGINT) will be ignored(Try pressing Ctrl+C)\n");
	sleep(10);
	}
	printf("\nResetting SIGINT action to default:\n");
	//Reset the default action
	signalStatus=signal(SIGINT,SIG_DFL);
	if(signalStatus == SIG_ERR){
        perror("Error while trying to ignore signal!");
	}
	else{
	sleep(10);
	}
	return 0;

}
/*prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ gcc 9.c
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./a.out
Any interrupt from keyboard(SIGINT) will be ignored(Try pressing Ctrl+C)
^C
^C
^C

Resetting SIGINT action to default:
^C
*/
