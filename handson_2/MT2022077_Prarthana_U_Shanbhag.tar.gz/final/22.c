// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to wait for data to be written into FIFO within 10 seconds, use select system call with FIFO.

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>


int main() {


fd_set rfds;
struct timeval tv;
int retval;
char buff[50];
int fd = open("myfifo", O_RDONLY);
    /* see when FIFO has input. */
FD_ZERO(&rfds);
FD_SET(fd, &rfds);
    /* Wait up to ten seconds. */
tv.tv_sec = 10;//sec
tv.tv_usec = 0;//micro sec


retval=select(fd + 1, &rfds, NULL, NULL, &tv);////(highest file desc+1, readfd,writefd,exceptional condition,timespec)
  


if (retval==0)
printf("No data is available for reading yet\n");
else if(retval==1) {
printf("Data is available now\n");
read(fd, buff, sizeof(buff));
printf("Data from FIFO: %s\n", buff);
}
else{
printf("Error in select statement");
}

return 0;
}

