// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a simple program to create three threads.
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
pthread_t tid[3]; //To store thread id's

void* thread_func(void *arg)
{
	pthread_t id = pthread_self(); //to obtain ID of calling thread

	if(pthread_equal(id,tid[0]))//to compare the thread id's
		printf("This is Thread 1 executing!!\n");
	else if(pthread_equal(id,tid[1]))
		printf("This is Thread 2 executing!!\n");
	else
		printf("This is Thread 3 executing!!\n");

	return NULL;
}


int main()
{
	int i=0,ret;

	while(i<3)
	{
		ret = pthread_create(&(tid[i]),NULL,&thread_func,NULL);
		if(ret!=0)
		{
			perror("pthread_create ERROR");
			return -1;
		}
		else
			printf("Thread %d created successfully!\n",i+1);
		i++;
	}
	sleep(5);
	printf("Program Exiting....\n");
	return 0;
}
/*
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ gcc 6.c -lpthread
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./a.out
Thread 1 created successfully!
This is Thread 1 executing!!
Thread 2 created successfully!
This is Thread 2 executing!!
Thread 3 created successfully!
This is Thread 3 executing!!

Program Exiting....
*/