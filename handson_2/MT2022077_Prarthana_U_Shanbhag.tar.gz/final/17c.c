// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to execute ls -l | wc.  c) use fcntl
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

int main(){
int fd[2];
pipe(fd);

if (!fork()) {
close(1); 				// close STDOUT
fcntl(fd[1], F_DUPFD, 1);		// Duplicate fd[1] to lowest fd value available = 1
close(fd[0]);	
execlp("ls", "ls", "-l", NULL); 	// execlp() will write output of "ls -l" to fd with value = 1 (write-end of pipe)
}
else {
close(0); // close STDIN
close(fd[1]);
fcntl(fd[0], F_DUPFD, 0);				// Duplicate fd[0] to lowest fd value available = 0
execlp("wc", "wc", NULL);  		// execlp() will read input from fd with value = 0 (read-end of pipe) as input to “wc” command and show output to fd with value = 1 => STDOUT
}


return 0;
}




