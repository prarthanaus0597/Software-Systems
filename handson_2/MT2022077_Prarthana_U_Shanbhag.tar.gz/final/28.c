// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to change the exiting message queue permission. (use msqid_ds structure)
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

//use sudo to change the permission
int main(int argc,char **argv){
if(argc<2){
printf("Enter a token for msgid as command line argument\n ");
}
else{
char arg=argv[1][0];
int key = ftok(".", arg);

int msgid = msgget(key,IPC_CREAT|0744);	

if (msgid == -1) {
	printf("Error while accessing Msg queue  with key %d. \n",key);
}

else {
	struct msqid_ds queue_info;
	int mode ;
	printf("Enter the mode of the queue in octal(0-7)\n");
	scanf("%o",&mode);
        

        /* Change the permissions using an old trick */
        //sscanf(mode, "%o", &queue_info.msg_perm.mode);
	queue_info.msg_perm.mode=mode;
        /* Update the internal data structure */
        if( msgctl( msgid, IPC_SET, &queue_info) == -1)
        {
                return(-1);
        }
}


}

return 0;
}

