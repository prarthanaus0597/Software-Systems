// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Create a FIFO file by
//e. mkfifo library function


#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>


//d) mkfifo() system call



int main(){

//mkfifo(“filename”, file_permissions); // Returns 0 on success else -1

char buf[50];
printf("Enter the name of fifo file to be created !!");
scanf("%s",buf);
int res=mkfifo(buf, 0744); ;
if(res==0){
printf("FIFO Created !!\n");
}
else{
printf("FIFO Already exist\n");
}
return 0;
}

