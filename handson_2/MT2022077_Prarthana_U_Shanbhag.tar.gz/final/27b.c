// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to receive messages from the message queue. b) with 0 as a flag
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>


int main(int argc,char **argv){
if(argc<2){
printf("Enter a token for msgid as command line argument\n ");
}
else{

struct msg {
long int msg_type;
char msg_text[80];
} msg_queue;

char arg=argv[1][0];

int key = ftok(".", arg);
int msgqid = msgget(key, IPC_CREAT|0744);
if(msgqid==-1){
printf("Error while accessing Msg queue  with key  %d. \n",key);
}
else{
printf("Enter message type: ");
scanf("%ld", &msg_queue.msg_type);
//msgflg specifies action to be taken if msg of specified type not present in the queue  
//msgflag=0 suspends the execution until msg queue is removed from the system
int ret = msgrcv(msgqid, &msg_queue, sizeof(msg_queue.msg_text), msg_queue.msg_type,0|MSG_NOERROR);
if (ret == -1)
printf("Error recieving the msg !!\n");
else{
printf("Message type: %ld\n Message: %s\n", msg_queue.msg_type, msg_queue.msg_text);
}
}
}
return 0;
}

