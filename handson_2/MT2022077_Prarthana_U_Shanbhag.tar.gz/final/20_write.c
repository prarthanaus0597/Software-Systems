// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write two programs so that both can communicate by FIFO -Use one way communication.

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
//writing to fifo file 
int main() {
char buff[50];
printf("Enter the text:\n ");
//scanf("%s", buff);
remove("myfifo20");
int ret = mkfifo("myfifo20",0666); //create FIFO
int fd = open("myfifo20", O_WRONLY,0777);
if(fd!=-1){
scanf("%s",buff);
write(fd, buff, sizeof(buff));
printf("Message sent: %s\n",buff);
}
else{
printf("Fd:%d, Error!!",fd);
}
return 0;
}
