// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: 
/* Write a program to print a message queue's (use msqid_ds and ipc_perm structures)
a. access permission
b. uid, gid
c. time of last message sent and received
d. time of last change in the message queue
d. size of the queue
f. number of messages in the queue
g. maximum number of bytes allowed
h. pid of the msgsnd and msgrcv
*/



#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include   <sys/types.h>
#include   <sys/ipc.h>
#include   <sys/msg.h>
#include   <time.h>


int main(int argc,char **argv){
if(argc<2){
printf("Enter a token for msgid as command line argument\n ");
}
else{

char arg=argv[1][0];
struct msqid_ds queue_info;
//int msgctl(int msqid, int cmd, struct msqid_ds *buf);
int key = ftok(".", arg);
int msqid= msgget(key, IPC_CREAT|0744);

if(msqid==-1){
printf("error getting the msg queue id!!\n");
exit(0);
}



int stats =msgctl(msqid,IPC_STAT,&queue_info);
if(stats!=0){
printf("Error");
}
else{
printf("a. access permission by user ,group and others is %o repectively.\n",queue_info.msg_perm.mode);

printf("b. uid :%d, gid :%d\n",(int)queue_info.msg_perm.uid,(int)queue_info.msg_perm.gid);
printf("c. time of last message sent is: %s \ntime of last message received is: %s\n",ctime(&queue_info.msg_stime),ctime(&queue_info.msg_rtime));
printf("d. time of last change in the message queue: %s\n",ctime(&queue_info.msg_ctime));
printf("e. size of the queue :%ld\n",queue_info.msg_cbytes);
printf("f. number of messages in the queue:%lu\n",queue_info.msg_qnum);
printf("g. maximum number of bytes allowed:%lu\n",queue_info.msg_qbytes);
printf("h. pid of the msgsnd and msgrcv:%d and %d respectively \n",queue_info.msg_lspid,queue_info.msg_lrpid);


}
}
return 0;
}


