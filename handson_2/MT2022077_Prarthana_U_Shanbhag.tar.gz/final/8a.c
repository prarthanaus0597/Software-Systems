// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question : Write a separate program using signal system call to catch the following signals.a) SIGSEGV
//SIGSEGV = Invalid memory reference (man 7 signal)
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>

void handler_func(int signum)
{
	if(signum==SIGSEGV)
		printf("Caught Signal SIGSEGV!!!\n");
	else
		printf("Invalid signal\n");
}

int main()
{
	typedef void (*sighandler_t)(int);

	signal(SIGSEGV, (sighandler_t)handler_func); //to change the disposition of signal(to determine how process behaves on getting signal)
	printf("Send segmentation fault signal!!!\n");
	//Explicitly send signal to this process using kill system call
	int ret = kill(getpid(),SIGSEGV);// Send segmentation fault signal
	if(ret==-1)
	{
		perror("KILL ERROR");
		return -1;
	}
	return 0;

}