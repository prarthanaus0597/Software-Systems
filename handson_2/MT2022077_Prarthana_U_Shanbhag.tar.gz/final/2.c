// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to print the system resource limits. Use getrlimit system call.


#include <sys/time.h>
#include <sys/resource.h>
#include <stdio.h>
#include <unistd.h>

int main()
{
	int retval;
	struct rlimit limit;
	
    // RLIMIT_CPU -> Amount of CPU time that the process can consume
	retval = getrlimit(RLIMIT_CPU,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Amount of CPU time that a process can consume:\n");
		printf("Soft Limit : %lu seconds\n",limit.rlim_cur);
		printf("Hard Limit : %lu seconds\n\n",limit.rlim_max);
	}
	// RLIMIT_STACK -> Maximum  size of the process stack

	retval = getrlimit(RLIMIT_STACK ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Maximum  size of the process stack:\n");
		printf("Soft Limit : %lu bytes\n",limit.rlim_cur);
		printf("Hard Limit : %lu bytes\n\n",limit.rlim_max);
	}
	
	// RLIMIT_SIGPENDING ->The number of signals that may be queued

	retval = getrlimit(RLIMIT_SIGPENDING  ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("The number of signals that may be queued:\n");
		printf("Soft Limit : %lu \n",limit.rlim_cur);
		printf("Hard Limit : %lu \n\n",limit.rlim_max);
	}
	
	// RLIMIT_RTTIME -> Amount of CPU time that a  process scheduled  under a real-time scheduling policy may consume without making a blocking system call.

	retval = getrlimit(RLIMIT_RTTIME   ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Amount of CPU time that a  process scheduled  under a real-time scheduling policy may consume without making a blocking system call:\n");
		printf("Soft Limit : %lu ms \n",limit.rlim_cur);
		printf("Hard Limit : %lu ms \n\n",limit.rlim_max);
	}

	// RLIMIT_RTPRIO -> a ceiling on the real-time priority

	retval = getrlimit(RLIMIT_RTPRIO    ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("a ceiling on the real-time priority:\n");
		printf("Soft Limit : %lu \n",limit.rlim_cur);
		printf("Hard Limit : %lu \n\n",limit.rlim_max);
	}
 // RLIMIT_RSS -> Limit on the number of virtual pages resident in the RAM
	retval = getrlimit(RLIMIT_RSS     ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Limit on the number of virtual pages resident in the RAM:\n");
		printf("Soft Limit : %lu \n",limit.rlim_cur);
		printf("Hard Limit : %lu \n\n",limit.rlim_max);
	}

 // RLIMIT_NPROC -> Limit on the number of threads
retval = getrlimit(RLIMIT_NPROC      ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Limit on the number of threads:\n");
		printf("Soft Limit : %lu \n",limit.rlim_cur);
		printf("Hard Limit : %lu \n\n",limit.rlim_max);
	}
// RLIMIT_NOFILE -> specifies a value one greater than the maximum file descriptor number that can be opened by this process
retval = getrlimit(RLIMIT_NOFILE      ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("specifies a value one greater than the maximum file descriptor number that can be opened by this process:\n");
		printf("Soft Limit : %lu \n",limit.rlim_cur);
		printf("Hard Limit : %lu \n\n",limit.rlim_max);
	}
// RLIMIT_NICE -> Ceiling of the process's nice value
retval = getrlimit(RLIMIT_NICE    ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Ceiling of the process's nice value:\n");
		printf("Soft Limit : %lu \n",limit.rlim_cur);
		printf("Hard Limit : %lu \n\n",limit.rlim_max);
	}
// RLIMIT_MSGQUEUE -> Maximum number of bytes that can be allocated for POSIX message queues
retval = getrlimit(RLIMIT_MSGQUEUE    ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Maximum number of bytes that can be allocated for POSIX message queues:\n");
		printf("Soft Limit : %lu bytes \n",limit.rlim_cur);
		printf("Hard Limit : %lu bytes \n\n",limit.rlim_max);
	}
// RLIMIT_MEMLOCK -> Maximum number of bytes of memory that may be locked into RAM
retval = getrlimit(RLIMIT_MEMLOCK    ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Maximum number of bytes of memory that may be locked into RAM:\n");
		printf("Soft Limit : %lu bytes \n",limit.rlim_cur);
		printf("Hard Limit : %lu bytes \n\n",limit.rlim_max);
	}
// RLIMIT_LOCKS -> Maximum number of locks that a process may establish
retval = getrlimit(RLIMIT_LOCKS      ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Maximum number of locks that a process may establish:\n");
		printf("Soft Limit : %lu \n",limit.rlim_cur);
		printf("Hard Limit : %lu \n\n",limit.rlim_max);
	}
// RLIMIT_FSIZE -> Maximum size of files that  the  process  may  create
retval = getrlimit(RLIMIT_FSIZE     ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Maximum size of files that  the  process  may  create:\n");
		printf("Soft Limit : %lu bytes \n",limit.rlim_cur);
		printf("Hard Limit : %lu bytes \n\n",limit.rlim_max);
	}
// RLIMIT_DATA -> Maximum size of the process's data segment
retval = getrlimit(RLIMIT_DATA    ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf(" Maximum size of the process's data segment:\n");
		printf("Soft Limit : %lu bytes  \n",limit.rlim_cur);
		printf("Hard Limit : %lu bytes \n\n",limit.rlim_max);
	}
// RLIMIT_CORE -> Max size of a core file

retval = getrlimit(RLIMIT_CORE     ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Max size of a core file:\n");
		printf("Soft Limit : %lu bytes  \n",limit.rlim_cur);
		printf("Hard Limit : %lu bytes \n\n",limit.rlim_max);
	}

	// RLIMIT_AS -> This  is  the maximum size of the process's virtual memory (address space).
	retval = getrlimit(RLIMIT_AS     ,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("the maximum size of the process's virtual memory (address space):\n");
		printf("Soft Limit : %lu bytes \n",limit.rlim_cur);
		printf("Hard Limit : %lu bytes \n\n",limit.rlim_max);
	}

	return 0;
}