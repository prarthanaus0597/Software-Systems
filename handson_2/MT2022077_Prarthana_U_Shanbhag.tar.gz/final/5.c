// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:
/*Write a program to print the system limitation of
a. maximum length of the arguments to the exec family of functions.
b. maximum number of simultaneous process per user id.
c. number of clock ticks (jiffy) per second.
d. maximum number of open files
e. size of a page
f. total number of pages in the physical memory
g. number of currently available pages in the physical memory.
*/

#include <unistd.h>
#include <stdio.h>

int main()
{
	printf("****SYSTEM LIMITS****\n");
	printf("a. Maximum length of args to exec() family of functions = %ld\n",sysconf(_SC_ARG_MAX));
	printf("b. Maximum number of simultaneous processes per user ID = %ld\n",sysconf(_SC_CHILD_MAX));
	printf("c. The number of clock ticks per second = %ld\n",sysconf(_SC_CLK_TCK));
	printf("d. Maximum number of files that a process can have open at any time = %ld\n",sysconf(_SC_OPEN_MAX));
	printf("e. Size of a page = %ld bytes\n",sysconf(_SC_PAGESIZE));
	printf("f. The  number of pages of physical memory = %ld\n",sysconf(_SC_PHYS_PAGES));
	printf("g. The number of currently available pages of physical memory = %ld\n",sysconf(_SC_AVPHYS_PAGES));

	
	return 0;
}