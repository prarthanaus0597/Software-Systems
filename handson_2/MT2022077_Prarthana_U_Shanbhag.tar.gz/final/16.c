// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to send and receive data from parent to child vice versa. Use two waycommunication.

#include <stdio.h>
#include <unistd.h>
#include <string.h>


int main(){
int fd1[2];
int fd2[2];
char buf1[50];
char buf2[50];
pipe(fd1);
pipe(fd2);
if(!fork()){
//child
close(fd1[0]);
close(fd2[1]);
printf("Child : PLease enter the msg to be sent to parent-\n");
scanf("%[^\n]",buf1);
write(fd1[1],buf1,sizeof(buf1));
read(fd2[0],buf2,sizeof(buf2));
printf("Msg sent by parent & recieved by child :%s\n",buf2);


}
else{
//parent 
close(fd1[1]);
close(fd2[0]);
read(fd1[0],buf1,sizeof(buf1));
printf("Parent : PLease enter the msg to be sent to child-\n");
scanf("%[^\n]",buf2);
write(fd2[1],buf2,sizeof(buf2));
printf("Msg sent  by child & recieved by parent is :%s\n",buf1);
}


return 0;
}

