// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to ignore a SIGINT signal then reset the default action of the SIGINT signal - use sigaction system call.
//using sigaction()
#include <stdio.h>
#include <unistd.h>
#include <signal.h>

int main()
{
	struct sigaction sa;
	int signalStatus; // Determines the success of the `sigaction` call
	
	//Ignore SIGINT signal
	sa.sa_handler = SIG_IGN;
	signalStatus=sigaction(SIGINT,&sa,NULL);
	if(signalStatus == -1){
        perror("Error while trying to ignore signal!");
	}
	else{
	printf("Any interrupt from keyboard(SIGINT) will be ignored!!!\n");
	sleep(10);
	}
	printf("Resetting SIGINT action to default:\n");
	//Reset the default action
	sa.sa_handler = SIG_DFL;
	signalStatus=sigaction(SIGINT,&sa,NULL);
	if(signalStatus == -1){
        perror("Error while trying to ignore signal!");
	}
	else{
	sleep(10);
	}
	return 0;

}
/*
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ gcc 11.c
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./a.out
Any interrupt from keyboard(SIGINT) will be ignored!!!
^C^C^C^C
Resetting SIGINT action to default:
^C
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$
*/