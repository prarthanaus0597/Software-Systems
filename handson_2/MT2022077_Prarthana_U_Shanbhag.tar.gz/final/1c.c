// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a separate program (for each time domain) to set a interval timer in 10sec and 10micro second .c) ITIMER_PROF
//ITIMER_PROF -----> SIGPROF signal is generated when expired

#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>
void timer_handler(int n)
{
	
	printf("Timer expired,SIGPROF signal generated!\n");
}

int main()
{
	struct itimerval timer;
	struct sigaction sa;
	printf("Waiting for alarm\n");
	//setting action to be taken when signal is generated
	/*sa.sa_handler = &timer_handler;
	int retval = sigaction(SIGPROF,&sa,NULL);//change signal action
	if(retval==-1)
	{
		perror("SIGACTION ERROR");
		return -1;
	}
	*/
	//Configure the timer to expire initially after 10sec+10us
	timer.it_value.tv_sec =10;//seconds
	timer.it_value.tv_usec =10;//microseconds

	//and then expire at interval of 10sec+10usec every time
	//value 0 means single shot timer, expires only once
	timer.it_interval.tv_sec =10;//seconds
	timer.it_interval.tv_usec =10;//microseconds
	
	//setitimer
	int ret = setitimer(ITIMER_PROF,&timer,NULL);
	if(ret==-1)
	{
		perror("SETITIMER ERROR");
		return -1;
	}

	while(1);
	return 0;
}
/*

prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ gcc 1c.c
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./a.out
Waiting for alarm
Timer expired,SIGPROF signal generated!
Profiling timer expired
*/