// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to create a shared memory. b) attach with O_RDONLY and check whether you are able to overwrite.
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>

int main(int argc,char **argv){
if(argc<2){
printf("Enter a token for msgid as command line argument\n ");
}
else{
char arg=argv[1][0];
int key = ftok(".", arg);
//1Mb size
int ret = shmget(key,1024,IPC_CREAT|0744);	

if(ret ==-1)
printf("Error occured while creating the shared memory!!\n");
else{
printf("Created the shared memory!!\n");
int shmid=ret;
char *data=shmat(shmid,0,SHM_RDONLY); 
printf("Enter the data to be stored :\n");
int r=scanf("%s",data);// segmentation fault occurs if we try to write as its readonly

}
}
return 0;
}

