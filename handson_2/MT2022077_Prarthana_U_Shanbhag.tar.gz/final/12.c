// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to create an orphan process. Use kill system call to send SIGKILL signal to the parent process from the child process.
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <stdlib.h>
int main()
{
	int pid = fork(); //create child process

	if(pid==-1)
	{
		perror("FORK ERROR");
		return -1;
	}
	else if(pid==0)
	{	//Child Process
		printf("Hi, Child here!!\n");
		printf("Sending SIGKILL signal to Parent with ID = %d to terminate it!!\n",getppid());

		kill(getppid(),SIGKILL);
		sleep(5);
		printf("New Parent ID after killing original parent = %d\n",getppid());
		sleep(1);
		printf("Child Terminated!\n");
		

	}
	else
	{	//Parent Process
		printf("Hi, Parent here with ID = %d\n",getpid());
		sleep(3);
	}
	exit(0);
}
/*
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ gcc 12.c
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./a.out
Hi, Parent here with ID = 864
Hi, Child here!!
Sending SIGKILL signal to Parent with ID = 864 to terminate it!!
Killed
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ New Parent ID after killing original parent = 209
Child Terminated!
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ps 209
  PID TTY      STAT   TIME COMMAND
  209 ?        S      0:00 /init
*/
