// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a separate program using sigaction system call to catch the following signals. c) SIGFPE

//SIGFPE(all arithmetic errors) using sigaction
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

void mySig_Handler(int signum)
{
	printf("\nCaught SIGFPE signal and exiting...\n");
	exit(0);
}

int main()
{
	struct sigaction sa;
	sa.sa_handler = &mySig_Handler;

	sigaction(SIGFPE,&sa,NULL);

	//Generating SIGFPE signal by dividing by 0
	int n;
	printf("Enter any number:\n");
	scanf("%d",&n);
	printf("Dividing input number by 0...\n");
	int m = n/0;

	return 0;
}

/*
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ gcc 10c.c -w
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./a.out
Enter any number:
1
Dividing input number by 0...

Caught SIGFPE signal and exiting...
*/