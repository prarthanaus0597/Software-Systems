// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to detach the shared memory
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <wait.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/shm.h>


const char *sh_mem = "Hello there!";

int main(int argc,char **argv){
if(argc<2){
printf("Enter a token for msgid as command line argument\n ");
}
else{
	char arg=argv[1][0];
	int key = ftok(".", arg);
	//1Mb size
	int shmid = shmget(key,1024,IPC_CREAT|0744);	
	int status=-1;
	sh_mem = (char *) shmat(shmid, NULL, 0);

    	printf("Segment ID %d\n", shmid);
    	printf("Attached at %p\n", sh_mem);
   	//memmove(sh_mem, data, strlen(data)+1);
   	//printf("%s\n", sh_mem);
getchar();
    	status=shmdt(sh_mem);
	
    	if(status==0){
    	printf("Detached the shared memory\n");
    	}
    	else{
    	printf("Error occured while detaching the shared memory!!\n");
    	}
    	
    	
  }
}
