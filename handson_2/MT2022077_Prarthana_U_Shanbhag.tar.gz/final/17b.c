// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to execute ls -l | wc.  b) use dup2
#include <stdio.h>
#include <unistd.h>
#include <string.h>


int main(){
int fd[2];
pipe(fd);

if (!fork()) {
close(1); 				// close STDOUT
dup2(fd[1], 1); 				// Duplicate fd[1] to lowest fd value available = 1
close(fd[0]);	
execlp("ls", "ls", "-l", NULL); 	// execlp() will write output of "ls -l" to fd with value = 1 (write-end of pipe)
}
else {
close(0); // close STDIN
close(fd[1]);
dup2(fd[0], 0) ;				// Duplicate fd[0] to lowest fd value available = 0
execlp("wc", "wc", NULL);  		// execlp() will read input from fd with value = 0 (read-end of pipe) as input to “wc” command and show output to fd with value = 1 => STDOUT
}


return 0;
}




