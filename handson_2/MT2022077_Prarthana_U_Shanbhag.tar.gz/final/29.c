// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to remove the message queue.
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>


int main(int argc,char **argv){
if(argc<2){
printf("Enter a token for msgid as command line argument\n ");
}
else{
char arg=argv[1][0];

int key = ftok(".", arg);
int msgid = msgget(key, 0);	

if (msgid == -1) {
	printf("Message queue does not exists.\n");
}
else if (msgctl(msgid, IPC_RMID, NULL) == -1) {
	printf( "Message queue could not be deleted.\n");
		
}
else {
	printf( "Message queue  deleted.\n");
}
}
return 0;
}

