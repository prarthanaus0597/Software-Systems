// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a simple program to create a pipe, write to the pipe, read from pipe and display on the monitor.

#include <stdio.h>
#include <unistd.h>
#include <string.h>


int main(){
int fd[2];
char buf[40];
int len=strlen("Hi how are you?");
pipe(fd);
write(fd[1],"Hi how are you?\n",len);
read(fd[0],buf,len);
printf("%s\n",buf);
return 0;
}
