// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to remove the Shared memory
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

const char *sh_mem = "Hello there!";

int main(int argc,char **argv){
if(argc<2){
printf("Enter a token for msgid as command line argument\n ");
}
else{
	char arg=argv[1][0];
	int key = ftok(".", arg);
	//1Mb size
	int shmid = shmget(key,1024,0);	
	int status=-1;
	sh_mem = (char *) shmat(shmid, NULL, 0);
	

    	printf("Segment ID %d\n", shmid);

	if (shmid == -1) {
	printf("Shared memory does not exists.\n");
	}
	else if (shmctl(shmid, IPC_RMID, NULL) == -1) {
	printf( "Shared memory could not be deleted.\n");		
	}
	else {
	printf( "Shared memory deleted\n");
	}
}

return 0;
}

