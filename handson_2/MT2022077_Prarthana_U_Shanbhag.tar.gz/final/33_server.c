// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Question: Write a program to communicate between two machines using socket. b)server
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

//function for sorting
int* sort_func(int temp[],int n)
{	
	int j,k,min,t;
	for(j=0;j<n-1;j++)
	{
		min=j;
		for(k=j+1;k<n;k++)
		{
			if(temp[k]<temp[min])
				min = k;
		}
		//swap the min element and temp[j]
		t =temp[min];
		temp[min]= temp[j];
		temp[j]=t;

	}
	return temp;

}

int main(int argc, char const *argv[])
{
	int sockfd_server;//file descriptor that refers to endpoint

	sockfd_server = socket(AF_INET,SOCK_STREAM,0);//create socket
	if(sockfd_server==-1)
	{
		perror("SOCKET ERROR");
		return -1;
	}

	//bind the socket to the address and port number (assign name to the socket)
	struct sockaddr_in server_addr;

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(9734);//convert values b/w host and network byte order
	server_addr.sin_addr.s_addr = INADDR_ANY; //bind server to all local interfaces

	bind(sockfd_server,(struct sockaddr *)&server_addr,sizeof(server_addr));

	//create socket queue using listen() to accept incoming requests
	listen(sockfd_server,5);
	while(1)
	{
	printf("SERVER WAITITNG....\n");

	//accept a connection--- creates new socket to communicate with particular client
	struct sockaddr_in client_addr;// contains clients address info
	int addrlen = sizeof(client_addr);
	int new_sockfd = accept(sockfd_server,(struct sockaddr *)&client_addr,(socklen_t *)&addrlen);
	printf("****CONNECTED WITH CLIENT****\n");


	int input_arr[7],*output_arr,i=0;
	read(new_sockfd,&input_arr,sizeof(input_arr));
	printf("Received numbers:\n");
	for(i=0;i<7;i++)
	{
		printf("%d\t",input_arr[i]);
	}
	printf("\nSorting the above list and sending it to client..\n");
	output_arr = sort_func(input_arr,7);
	write(new_sockfd,output_arr,7*sizeof(int));
	printf("SENT TO CLIENT\n");
	printf("CLOSING THE CONNECTION..\n");
	close(new_sockfd);
	}
	return 0;
}

/*prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ gcc 33_server.c -o server.out
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./server.out
SERVER WAITITNG....
****CONNECTED WITH CLIENT****
Received numbers:
10      3       5       2       7       1       8
Sorting the above list and sending it to client..
SENT TO CLIENT
CLOSING THE CONNECTION..
SERVER WAITITNG....*/