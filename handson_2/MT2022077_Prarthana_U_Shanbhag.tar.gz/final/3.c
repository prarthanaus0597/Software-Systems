// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to set (any one) system resource limit. Use setrlimit system call.
#include <sys/time.h>
#include <sys/resource.h>
#include <stdio.h>
#include <unistd.h>

int main()
{
	int retval;
	struct rlimit limit;
// RLIMIT_CPU -> Amount of CPU time that the process can consume
	retval = getrlimit(RLIMIT_CPU,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Amount of CPU time that a process can consume before changing:\n");
		printf("Soft Limit : %lu seconds\n",limit.rlim_cur);
		printf("Hard Limit : %lu seconds\n\n",limit.rlim_max);
	}

	limit.rlim_cur=1; //soft limit
	limit.rlim_max=1; //hard limit

	retval= setrlimit(RLIMIT_CPU,&limit);
	if(retval==-1)
	{
		perror("SETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Modified RLIMIT for RLIMIT_CPU :\n");
		printf("Soft Limit = %lu second\n", limit.rlim_cur);
		printf("Hard Limit = %lu second\n", limit.rlim_max);
	}
	return 0;
}