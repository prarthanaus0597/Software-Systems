// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to receive messages from the message queue. a) with IPC_NOWAIT as a flag
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>


int main(int argc,char **argv){
if(argc<2){
printf("Enter a token for msgid as command line argument\n ");
}
else{

struct msg {
long int msg_type;
char msg_text[80];
} msg_queue;

char arg=argv[1][0];

int key = ftok(".", arg);
int msgqid = msgget(key, IPC_CREAT|0744);
if(msgqid==-1){
printf("Error while accessing Msg queue  with key %d. \n",key);
}
else{
printf("Enter message type: ");
scanf("%ld", &msg_queue.msg_type);
//IPC_NOWAIT: Return immediately if no message of the requested type is in the queue.  The system call fails with errno set to ENOMSG.
//MSG_NOERROR : To truncate the message text if longer than msgsz bytes.
int ret = msgrcv(msgqid, &msg_queue, sizeof(msg_queue.msg_text), msg_queue.msg_type,IPC_NOWAIT|MSG_NOERROR);
if (ret == -1)
printf("Error recieving the msg !!\n");
else{
printf("Message type: %ld\n Message: %s\n", msg_queue.msg_type, msg_queue.msg_text);
}
}
}
return 0;

}

