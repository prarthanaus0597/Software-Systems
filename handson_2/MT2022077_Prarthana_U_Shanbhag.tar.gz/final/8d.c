// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question : Write a separate program using signal system call to catch the following signals.d) SIGALRM (use alarm system call)
//SIGALRM = Timer signal from alarm() (man 7 signal)
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>

void handler_func(int signum)
{
	if(signum == SIGALRM)
		printf("Caught Signal SIGALRM!!!\n");
	else
		printf("Invalid signal\n");
}

int main()
{
	typedef void (*sighandler_t)(int);

	signal(SIGALRM,(sighandler_t)handler_func); //to change the disposition of signal(to determine how process behaves on getting signal)
	printf(" Timer signal from alarm()\n");

	alarm(10); //set an alarm clock for delivery of signal
	pause(); //wait for signal
	return 0;
}