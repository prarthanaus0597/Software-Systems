// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question : Program to print created Thread ID
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void * thread_func(void *arg)
{

	return NULL;
}

int main()
{
	pthread_t tid;
	int ret;

	ret = pthread_create(&tid,NULL,&thread_func,NULL);
	if(ret!=0)
	{
		perror("THREAD CREATE ERROR");
		return -1;
	}
	else
		printf("Thread created successfully with ID = %u\n",(unsigned int)tid);

	sleep(2);
	return 0;
}
/*
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ gcc 7.c -lpthread
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./a.out
Thread created successfully with ID = 3894703872
*/