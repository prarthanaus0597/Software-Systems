// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Create a FIFO file by
//a. mknod command
//b. mkfifo command
//c. use strace command to find out, which command (mknod or mkfifo) is better.
//d. mknod system call
//e. mkfifo library function


#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

//a) mknod
//	mknod myfifo p 
// 	p for FIFO pipe, c for character device , b for block devices 
//   terminal1: 
//      ls -l > myfifo 
//   terminal2:
//      wc < myfifo	
     

//b) mkfifo
//   terminal1: 
//	mkfifo a=rw myfifo
//      ls -l > myfifo 
//   terminal2:
//      wc < myfifo

//c) strace mkfifo myfifo
// strace mknod myfifo p	

//mkfifo actually calls mknod() and this mkfifo() is just doing some extra steps on top of mknod() because mkfifo() is a library function
//whereas mknod() is the actual system call.
//Therefore, mknod() is always going to be faster than mkfifo().


//d) mknod() system call



int main(){

//mknod(“filename”, S_IFIFO | file_permissions, device_special_number);
//For FIFO files, device_special_numbers = 0 since it is a pseudo device special file

char buf[50];
printf("Enter the name of fifo file to be created !!");
scanf("%s",buf);
int res=mknod(buf,S_IFIFO|0660,0);
if(res==0){
printf("FIFO Created !!\n");
}
else{
printf("FIFO Already exist\n");
}
return 0;
}

