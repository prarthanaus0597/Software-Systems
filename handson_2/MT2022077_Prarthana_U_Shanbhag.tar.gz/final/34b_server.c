// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:  Write a program to communicate between two machines using socket b) use pthread_create
//server side

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <pthread.h>

//start_routine for thread
void* calc_sum(int *newfd)
{
	int sum=0,num1=0,num2=0;
	int socket= *newfd;
	
	read(socket,&num1,sizeof(num1));
	sum+= num1;
	read(socket,&num2,sizeof(num2));
	sum+= num2;	
	
	write(socket,&sum,sizeof(sum));
	close(socket);	
	pthread_exit(NULL);
}

int main()
{
	int sockfd_server;
	sockfd_server = socket(AF_INET,SOCK_STREAM,0);//create socket
	if(sockfd_server==-1)
	{
		perror("SOCKET ERROR");
		return -1;
	}

	struct sockaddr_in server_addr;

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(9734);
	server_addr.sin_addr.s_addr = INADDR_ANY;

	bind(sockfd_server,(struct sockaddr *)&server_addr,sizeof(server_addr));

	listen(sockfd_server,5);
	while(1)
	{
		printf("SERVER WAITITNG....\n");
		struct sockaddr_in client_addr;// contains clients address info
		int addrlen = sizeof(client_addr);
		int new_sockfd = accept(sockfd_server,(struct sockaddr *)&client_addr,(socklen_t *)&addrlen);
		printf("****CONNECTED WITH CLIENT****\n");

		//create a thread to serve client request
		pthread_t tid;
		pthread_create(&tid,NULL,(void*)&calc_sum,&new_sockfd);

	}

	return 0;
}
/*$ gcc 34b_server.c -lpthread -o server.out
$ ./server.out
SERVER WAITITNG....
****CONNECTED WITH CLIENT****
SERVER WAITITNG....
****CONNECTED WITH CLIENT****
SERVER WAITITNG....

open 2 other terminals with client file
*/