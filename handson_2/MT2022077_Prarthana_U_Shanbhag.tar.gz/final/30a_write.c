// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to create a shared memory. a) write some data to the shared memory
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>



// ./a.out b & so that the attachment occur
int main(int argc,char **argv){
if(argc<2){
printf("Enter a token for msgid as command line argument\n ");
}
else{
char arg=argv[1][0];
int key = ftok(".", arg);
//1Mb size
int ret = shmget(key,1024,IPC_CREAT|0744);	

if(ret ==-1)
printf("Error occured while creating the shared memory!!\n");
else{
printf("Created the shared memory!!\n");
int shmid=ret;
char *data=shmat(shmid,0,0); 
printf("Enter the data to be stored :\n");
scanf("%s",data);
printf("Data is stored in  shared memory!!\n");
}
}
return 0;
}

