// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question :Write a separate program using sigaction system call to catch the following signals.a)SIGSEGV


//SIGSEGV using sigaction
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

void mySig_Handler(int signum)
{
	printf("Caught SIGSEGV signal (%d)!!\n",signum);
	exit(0);
}

int main()
{
	struct sigaction sa;
	sa.sa_handler = &mySig_Handler;

	sigaction(SIGSEGV,&sa,NULL);

	//Generating SIGSEGV signal
	int n;
	printf("Enter any number:\n");
	scanf("%d",n);

	return 0;

}

/*
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ gcc 10a.c -w
prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./a.out
Enter any number:
3
Caught SIGSEGV signal!!
*/