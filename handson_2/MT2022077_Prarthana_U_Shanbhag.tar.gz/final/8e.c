// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question : Write a separate program using signal system call to catch the following signals.e) SIGALRM (use setitimer system call)
//SIGALRM = Timer signal from alarm() using setitimer()(man 7 signal)
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/time.h>

void handler_func(int signum)
{
	if(signum == SIGALRM)
		printf("Caught Signal SIGALRM!!!\n");
	else
		printf("Invalid signal\n");
}

int main()
{
	typedef void (*sighandler_t)(int);

	signal(SIGALRM,(sighandler_t)handler_func); //to change the disposition of signal(to determine how process behaves on getting signal)

	
	struct itimerval timer;
	timer.it_value.tv_sec = 5; //seconds
	timer.it_value.tv_usec = 0; //microseconds

	//set periodic interval for timer to expire
	timer.it_interval.tv_sec =0;
	timer.it_interval.tv_usec =0;
	printf("Timer signal using setitimer()\n");
	setitimer(ITIMER_REAL,&timer,NULL);//set interval timer

	pause(); //wait for signal
	return 0;

}