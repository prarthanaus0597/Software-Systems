// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write two programs so that both can communicate by FIFO -Use two way communications

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
int main()
{
	
	//open clientFIFO for reading
	int fp_client = open("myfifo_client",O_RDONLY);
	if(fp_client==-1)
	{
		perror("OPEN CLIENTFIFO ERROR");
		return -1;
	}
	char readbuf[100];

	//read data from clientFIFO
	read(fp_client,readbuf,sizeof(readbuf));
	printf("Server Here: Message recieved from client is = %s",readbuf);

	close(fp_client);

	/*/////////////////////////////////////////////////////////////////////////////*/

	//open serverFIFO for writing
	int fp_server = open("myfifo_server",O_WRONLY);
	if(fp_server==-1)
	{
		perror("OPEN SERVERFIFO ERROR");
		return -1;
	}
	//write to serverFIFO
	char msg[]="Hello client!! Server here\n";

	write(fp_server,msg,strlen(msg));
	printf("Server Here: Message sent to client \n");
	close(fp_server);

	return 0;

}
