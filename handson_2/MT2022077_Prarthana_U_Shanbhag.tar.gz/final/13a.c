// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:first program is waiting to catch SIGSTOP signal

#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

void mySig_Handler(int signum)
{
	printf("\nCaught SIGSTOP signal and exiting...\n");
	exit(0);
}
int main()
{
	struct sigaction sa;
	sa.sa_handler = &mySig_Handler;

	sigaction(SIGSTOP,&sa,NULL);
	printf("Hi,My Process ID = %d\n",getpid());
	printf("Waiting to catch SIGSTOP signal\n");

	pause(); //wait for signal
	return 0;
}
/*prarthanaus@DESKTOP-GD31NHU:~/handson_2/handson_2$ ./13a.out
Hi,My Process ID = 985
Waiting to catch SIGSTOP signal
// signal is sent from 13b program 
[2]+  Stopped                 ./13a.out
*/