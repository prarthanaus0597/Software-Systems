// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a separate program using sigaction system call to catch the following signals.b) SIGINT 
//SIGINT using sigaction
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

void mySig_Handler(int signum)
{
	printf("\nCaught SIGINT signal (%d) and exiting...\n",signum);
	exit(0);
}

int main()
{
	struct sigaction sa;
	sa.sa_handler = &mySig_Handler;

	sigaction(SIGINT,&sa,NULL);

	//Generating SIGINT signal
	printf("Press Ctrl+C to generate SIGINT:\n");
	sleep(10);

	return 0;

}