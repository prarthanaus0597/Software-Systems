// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to communicate between two machines using socket a) use fork
//server side
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

int main()
{
	int sockfd_server;
	sockfd_server = socket(AF_INET,SOCK_STREAM,0);//create socket
	if(sockfd_server==-1)
	{
		perror("SOCKET ERROR");
		return -1;
	}

	struct sockaddr_in server_addr;

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(9734);
	server_addr.sin_addr.s_addr = INADDR_ANY;

	bind(sockfd_server,(struct sockaddr *)&server_addr,sizeof(server_addr));

	listen(sockfd_server,5);
	while(1)
	{
		printf("SERVER WAITITNG....\n");
		struct sockaddr_in client_addr;// contains clients address info
		int addrlen = sizeof(client_addr);
		int new_sockfd = accept(sockfd_server,(struct sockaddr *)&client_addr,(socklen_t *)&addrlen);
		printf("****CONNECTED WITH CLIENT****\n");

		int pid = fork();
		if(pid==-1)
		{
			perror("FORK ERROR");
			exit(1);
		}
		else if(pid==0)
		{	//Child will serve the request to new_sockfd
			int sum = 0,num,i=1;
			while(i<3)
			{
				read(new_sockfd,&num,sizeof(num));
				sum+= num;
				i++;
			}
			sleep(1);
			write(new_sockfd,&sum,sizeof(sum));
			close(new_sockfd);
			exit(0);

		}
		else
		{	//Parent will handle other clients requests
			close(new_sockfd);
		}

	}
	return 0;
}
// gcc 34a_server.c -o server.out
//./server.out