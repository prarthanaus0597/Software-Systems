// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a simple program to send some data from parent to the child process.

#include <stdio.h>
#include <unistd.h>
#include <string.h>


int main(){
int fd[2];

int len=strlen("hello how are you ?\n");
char buf[len];
pipe(fd);
if(fork()!=0){
//parent 
close(fd[0]);
write(fd[1],"hello how are you ?\n",len);
}
else{
//child

close(fd[1]);
//sleep(5);
read(fd[0],buf,len);
printf("Child recieved: %s ",buf);
}

return 0;
}

