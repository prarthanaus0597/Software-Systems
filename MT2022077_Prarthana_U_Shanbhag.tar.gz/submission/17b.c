// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:  program to open the file, implement write lock, read the ticket number, increment the number and print the new ticket number then close the file

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>


int main(int argc,char **argv,char **envi){
struct {
int ticket_no;
} db;

int fd=open("db.txt",O_RDWR,0744);
read(fd,&db,sizeof(db));
struct flock lock;
lock.l_type=F_WRLCK;
lock.l_whence=SEEK_SET;
lock.l_start=0;
lock.l_len=0;
lock.l_pid=getpid();
printf("Before entering critical section");
fcntl(fd,F_SETLKW,&lock);
printf("\nThe Write lock has been set.\nCurrent ticket number is: %d",db.ticket_no);
db.ticket_no++;
lseek(fd,0,SEEK_SET);
printf("\nInside critical section.\nEnter to unlock:");
write(fd,&db,sizeof(db));
getchar();
lock.l_type=F_UNLCK;
fcntl(fd,F_SETLKW,&lock);
printf("unlocked!!");
return 0;
}
