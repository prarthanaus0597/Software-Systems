// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to print the following information about a given file.
/* 
a. inode
b. number of hard links
c. uid
d. gid
e. size
f. block size
g. number of blocks
h. time of last access
i. time of last modification
j. time of last status change
*/

#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

int main(){
char b[100];
int readin=0;
int fd=open("source.txt",O_CREAT|O_RDONLY,0777);
struct stat info;

if(fd==-1)
{
printf("file doesnt exist");
}
else{
int stats =fstat(fd,&info);
if(stats!=0){
printf("Error");
}
else{
printf("Inode number:%d\n",(int)info.st_ino);
printf("Number of hard links:%d\n",(int)info.st_nlink);
printf("uid:%d \n",(int)info.st_uid);
printf("gid:%d\n",(int)info.st_gid);
printf("size:%d\n",(int)info.st_size);
printf("block size:%d\n",(int)info.st_blksize);
printf("Number of blocks:%d\n",(int)info.st_blocks);
printf("time last access:%s\n",ctime(&info.st_atime));
printf("time last modification:%s\n",ctime(&info.st_mtime));
printf("time last status change:%s\n",ctime(&info.st_ctime));

}
}
close(fd);
return 0;
}
