// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to open a file, duplicate the file descriptor and append the file with both the descriptors and check whether the file is updated properly or not. b) use dup2


#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

int main(){
int fd1=open("source.txt",O_CREAT|O_APPEND|O_WRONLY);
int fd2;
if(fd1==-1)
{
printf("file doesnt exist");
}
else{
int newfd;
dup2(fd1,newfd);//USES NEW NUMBER FOR SPECIFIED BY USER
printf("%d %d",fd1,newfd);
}
write(fd1,"Namaste\n",8);

return 0;
}
