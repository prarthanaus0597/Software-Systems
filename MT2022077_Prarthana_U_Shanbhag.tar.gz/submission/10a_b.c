// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to open a file with read write mode, write 10 bytes, move the file pointer by 10 bytes (use lseek) and write again 10 bytes.
/* 

a. check the return value of lseek 
b. open the file with od and check the empty spaces in between the data.
*/

#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

//send the file from command line 
int main(int argc,char **argv){
if(argc>2 || argc<=1){
printf("Enter only one source file name as command line argument\n");

}
else{
char *arg=argv[1];
char b[100];
int readin=0;
int fd=open(arg,O_RDWR);


if(fd==-1)
{
printf("file doesnt exist");
}
else{
read(fd,&b,10);
write(1,&b,10);

int lseek_return=lseek(fd,10,SEEK_CUR);
read(fd,&b,10);
write(1,&b,10);
printf("\nLseek returned %d\n",lseek_return);//offset location from beginning 

//b. od -c source.txt
}
close(fd);

}
return 0;
}
