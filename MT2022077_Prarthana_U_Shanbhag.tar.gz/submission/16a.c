// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: a program to perform mandatory locking. a) Implement write lock

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>




int main(int argc,char **argv,char **envi){

int fd=open("db.txt",O_CREAT|O_RDWR,0744);
printf("Before entering critical section");
struct flock lock;
lock.l_type=F_WRLCK;
lock.l_whence=SEEK_SET;
lock.l_start=0;
lock.l_len=0;
lock.l_pid=getpid();

fcntl(fd,F_SETLKW,&lock);
printf("\nThe Write lock has been set. press any key to unlock");
write(fd,"Hello",5);
getchar();
getchar();
printf("unlocked!!\n");
lock.l_type=F_UNLCK;
fcntl(fd,F_SETLKW,&lock);
return 0;
}
