// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Create a FIFO file using `mknod` system call


#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>


int main(){
	int mkfifo_status=mknod("fifofile", S_IFIFO|0666, 0);
	if(mkfifo_status ==-1)
	perror("Error found here");
	else
	printf("\nSuccesfully created FIFO file. Check using `ll` or `ls -l` command!\n");
	return 0;

}
