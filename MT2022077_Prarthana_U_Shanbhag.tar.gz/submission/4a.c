// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: a program to open an existing file with read write mode

#include <stdio.h>
#include<fcntl.h>


int main(){
int fd;
fd=open("file4.txt",O_CREAT|O_RDWR,0777);
//fd=creat("file2",0744);
printf("fd=%d",fd);
return 0;
}
