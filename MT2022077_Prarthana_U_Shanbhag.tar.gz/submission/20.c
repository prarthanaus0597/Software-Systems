// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Find out the priority of your running program. Modify the priority with nice command.
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>


int main(){
int priority=nice(0);
printf("Priority of program is :%d\n",priority);
priority=nice(-5);
printf("Priority of program is :%d\n",priority);// to change to negative we execute sudo ./a.out
sleep(20);
return 0;
}
