// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: a program to execute an executable program. b) pass some input to an executable program.(here 26_pre is executable program)

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

//run cc 26_pre.c -o 26.pre.out before running this code
int main(){
char *path="./26_pre.out";
char *arg1="hello ";
char *arg2="world";
execl(path, path,arg1,arg2,NULL);

return 0;
}
