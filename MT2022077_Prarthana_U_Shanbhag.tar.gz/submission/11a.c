// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to open a file, duplicate the file descriptor and append the file with both the descriptors and check whether the file is updated properly or not. a) use dup

#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

int main(){
int fd1=open("source.txt",O_CREAT|O_APPEND|O_WRONLY);
int fd2;
if(fd1==-1)
{
printf("file doesnt exist");
}
else{
fd2=dup(fd1);//USES NEW LOWER NUMBER FOR FD2
printf("%d %d",fd1,fd2);
}
write(fd1,"hello\n",5);
write(fd2,"world",5);
return 0;
}
