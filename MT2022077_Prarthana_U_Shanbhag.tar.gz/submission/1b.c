// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Create a hard link file using the `link` system call

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>


int main(){
	int fd=open("source.txt",O_CREAT|O_RDWR,0777);	
	int status =link("source.txt","hardlink.txt");
	if(status ==-1)
	perror("Error found here");
	else
	printf("\nHardlink created\n");
	return 0;

}
