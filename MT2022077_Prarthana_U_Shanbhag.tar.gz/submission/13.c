// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Program to wait for a STDIN for 10 seconds using select. Write a proper print statement to verify whether the data is available within 10 seconds or no

#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>

int main(void) {
    fd_set rfd;
   // fd_set wrfd;
    struct timeval tv;
    int retval;
    //int fd=open("source.txt",O_CREAT|O_RDWR,0744);
    /* see when stdin has input. */
    FD_SET(0, &rfd);
    //FD_SET(fd, &wrfd);
    /* Wait up to ten seconds. */
    tv.tv_sec = 10;//sec
    tv.tv_usec = 0;//micro sec
   
    retval = select(1, &rfd, NULL, NULL, &tv);//(highest file desc+1, readfd,writefd,exceptional condition,timespec)
  

    if (retval == -1)
        perror("select throwed error");
    else if (retval){
        printf("Data is available now.\n");
        
        }
    else
        printf("No data within 10 seconds.\n");
    return 0;
}
