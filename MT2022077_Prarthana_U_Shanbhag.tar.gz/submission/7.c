// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to copy file1 into file2 ($cp file1 file2).

#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#define buffersize 10000

//send the source file from command line 
int main(int argc,char **argv)
{
if(argc>2 || argc<=1){
printf("Enter only one source file name as command line argument \n");

}
else{
char buffer[buffersize]; 
ssize_t read_in,write_out; 

//printf("Enter source file name");
//scanf("%s",source);

char *arg=argv[1];
int sourcefiledesc = open(arg,O_RDONLY); 
if(sourcefiledesc < 0 )
{
printf("Source file doesnot Exist"); 
}
else
{
//printf("Enter destination file name");
//scanf("%s",destination);


int destfiledesc = open("destination",O_WRONLY|O_CREAT ,0744);
while((read_in = read(sourcefiledesc,&buffer,buffersize))>0)
{
write_out = write(destfiledesc,&buffer,read_in);
}
close(sourcefiledesc);
close(destfiledesc);
}
}
return 0;
}
