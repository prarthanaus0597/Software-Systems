// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
//QUestion :program to create a file and print the file descriptor value. Use creat ( ) system call

#include <stdio.h>
#include<fcntl.h>


int main(){
int fd;
//fd=open("file",O_CREAT|O_RDWR,0744);
fd=creat("file2.txt",0777);
printf("fd=%d\n",fd);
if(fd!=-1)
printf("file created!!\n");
else
printf("error");
return 0;
}
