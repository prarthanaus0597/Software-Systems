// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: a program to execute an executable program. a) use some executable program



#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>


int main(){
char *path="/bin/ls";
char *arg1="-lR";
execl(path,path,arg1,NULL);

return 0;
}
