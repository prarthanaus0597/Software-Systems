// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:a program to display the environmental variable of the user (use environ)

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>


int main(int argc,char **argv,char **envi){
//method1:
for(int i=0;envi[i]!=NULL;i++){
printf("%s\n",envi[i]);
//getchar();
}

//method2:
extern char **environ;
int i = 0;
while(environ[i]) {
  printf("%s\n", environ[i++]); // prints in form of "variable=value"
  getchar();
}


return 0;
}
