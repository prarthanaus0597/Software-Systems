// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question : Write a program to run a script at a specific time using a Daemon process

#include <time.h>      //  for time 
#include <stdio.h>
#include <string.h>     
#include <stdlib.h>    //  for itoa
#include <sys/types.h> //  for fork, setsid
#include <unistd.h>
#include <fcntl.h>    
#include <sys/stat.h>  //  for umask

// Argument to be passed as hour minute second (particular time of a day) hour is mandatory

int main(int argc, char *argv[])
{
    struct tm *deadline;               			 // Deadline in user readable format 
    pid_t child;
    int  fd=open("script.txt",O_CREAT|O_RDWR,0777);  
    time_t currentEpoch, deadlineEpoch; 		// Current system time & deadline time in posix time 
    
    // char *args[]={"./script.sh","./script.sh"};
    
    if (argc <=1 )
        printf("Pass at least hour argument\n");
    else
    {
        time(&currentEpoch); 				// Get current time
        deadline = localtime(&currentEpoch);		// set deadline from current time 
         
        //set deadline time using command line 
        deadline->tm_hour = atoi(argv[1]);
        deadline->tm_min = argv[2] == NULL ? 0 : atoi(argv[2]);
        deadline->tm_sec = argv[3] == NULL ? 0 : atoi(argv[3]);

       	deadlineEpoch = mktime(deadline); 		// Convert dealine to epoch
      
        if ((child = fork()) == 0)
        {
     
            pid_t sid= setsid();			//set session id
            
            if(sid<0)
            {
            	exit(0);
            }
            printf("Session id=%d\n",sid);		// print session id if no error
            chdir("/");					//change to root
            umask(0);					//set permission
            do
            {
            
                currentEpoch=time(NULL);
                
            } while (difftime(deadlineEpoch, currentEpoch) > 0); // waiting for the time specified to execute script
           
           
           /*can be used to run the script
            
            if(chdir("/home/prarthanaus/handson_list1/excer/submission")<0){ //change the directory to run the script.sh
            printf("Cannot change directory\n");
            exit(0);
            }
               
            execvp(args[0],args);*/
            
            
            //after waiting for specified time to exectue file write script 
            write(fd,"Daemon process is running and completed\n",strlen("Daemon process is running and completed"));
            exit(0);
        }
        exit(0);
    }
    return 0;
}
