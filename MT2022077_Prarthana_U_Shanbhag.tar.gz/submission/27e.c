// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:a program to execute ls -Rl by the following system calls execvp()


#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>


/* execvp : Using this command, the created child process does not have to run the same program as the parent process does. The exec type system calls allow a process to run any program files, which include a binary executable or a shell script . 
Syntax: 

int execvp (const char *file, char *const argv[]);

file: points to the file name associated with the file being executed. 
argv:  is a null terminated array of character pointers.
Let us see a small example to show how to use execvp() function in C. We will have two .C files , EXEC.c and execDemo.c and we will replace the execDemo.c with EXEC.c by calling execvp() function in execDemo.c .

*/

int main(){
char *args[]={"/bin/ls","-lR"};

printf("-------------------------------Output using execvp():--------------------------\n");
execvp(args[0],args);

return 0;
}
