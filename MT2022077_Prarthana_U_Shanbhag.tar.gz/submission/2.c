// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a simple program to execute in an infinite loop at the background. Go to /proc directory and identify all the process related information in the corresponding proc directory.



#include <stdio.h>


int main(){
	for(;;){}
	//./a.out & ,note process id , go to /proc/processid and see the information
	return 0;

}
