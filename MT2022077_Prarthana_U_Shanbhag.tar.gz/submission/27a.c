// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:a program to execute ls -Rl by the following system calls execl()

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>


/*
The execl() function replaces the current process image with a new process image specified by path. The new image is constructed from a regular, executable file called the new process image file. No return is made because the calling process image is replaced by the new process image.


int execl( const char * path,
           const char * arg0,
           const char * arg1,
           …
           const char * argn,
           NULL );
This function is declared in <process.h>, which <unistd.h> includes.

Arguments:
path -
The path of the file to execute.
arg0, …, argn -
Pointers to NULL-terminated character strings. These strings constitute the argument list available to the new process image. You must terminate the list with a NULL pointer. The arg0 argument must point to a filename that's associated with the process being started and cannot be NULL

*/

int main(){
char *command_path="/bin/ls";
char *options="-Rl";
//char *arg="2.c";
printf("-------------------------------Output using execl():----------------------------\n");
execl(command_path,command_path,options,NULL);

return 0;
}
