// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: program to open a file in read only mode, read line by line and display each line as it is read.Close the file when end of file is reached.

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

//send the file from command line 
int main(int argc,char **argv){
char b[10000];
int readin=0;
int i=0;



if(argc>2 || argc<=1){
printf("Enter only one source file name as command line argument\n");

}
else{
char *arg=argv[1];
int fd=open(arg,O_RDONLY);
if(fd==-1)
{
printf("Error in file opening\n");
}
else{
while((readin=read(fd,&b[i],1))>0){	

if(b[i]=='\n'){
write(1,&b,i+1);
i=0;
getchar();
}
else{
i++;
}
}
close(fd);
}
}
return 0;
}
