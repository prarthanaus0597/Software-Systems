// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: a program to perform mandatory locking. b) Implement read lock


#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>





//read lock

int main(int argc,char **argv,char **envi){

int fd=open("db.txt",O_CREAT|O_RDWR,0744);
char buff[10];
struct flock lock;
lock.l_type=F_RDLCK;
lock.l_whence=SEEK_SET;
lock.l_start=0;
lock.l_len=0;
lock.l_pid=getpid();
printf("Before entering critical section");
fcntl(fd,F_SETLKW,&lock);
printf("\nThe read lock has been set. press any key to unlock\n");
read(fd,&buff,10);
getchar();
getchar();
lock.l_type=F_UNLCK;
fcntl(fd,F_SETLKW,&lock);
printf("\nunlocked!!");
write(1,&buff,10);
return 0;
}
