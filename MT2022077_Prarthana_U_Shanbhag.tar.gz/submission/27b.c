// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:a program to execute ls -Rl by the following system calls execlp()




#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

/*
The execlp() function replaces the current process image with a new process image specified by file. The new image is constructed from a regular, executable file called the new process image file. No return is made because the calling process image is replaced by the new process image.

int execlp( const char * file, 
            const char * arg0, 
            const char * arg1,
            … 
            const char * argn, 
            NULL );
This function is declared in <process.h>, which <unistd.h> includes.

file :
Used to construct a pathname that identifies the new process image file. If the file argument contains a slash character, the file argument is used as the pathname for the file. Otherwise, the path prefix for this file is obtained by a search of the directories passed as the environment variable PATH.
arg0, …, argn :
Pointers to NULL-terminated character strings. These strings constitute the argument list available to the new process image. You must terminate the list with a NULL pointer. The arg0 argument must point to a filename that's associated with the process and cannot be NULL.

*/


int main(){
char *command_path="/bin/ls";
char *options="-lR";

printf("-------------------------------Output using execlp():--------------------------------------\n");
execlp(command_path,command_path,options,NULL);

return 0;
}
