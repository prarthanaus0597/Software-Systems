// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: a program, call fork and print the parent and child process id.


#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(){
//printf("\nParent process id 1 %d\n",getpid());
int c1=fork(),cid,pid;


if(c1==0){
	printf("\nchild is executing ");
	cid=getpid();
	printf("\nchild process id %d\n",cid);
	//printf("\n ppid process id %d\n",getppid());
}
else{
	printf("\nParent is executing ");
	pid=getpid();
	printf("\nParent process id %d\n",pid);
	
}


return 0;
}
