// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question : Write a program to get the scheduling policy and modify the scheduling policy (SCHED_FIFO, SCHED_RR).

#include <sched.h> // for sched_getscheduler and sched_setscheduler
#include <sys/types.h> //  for struct
#include <unistd.h>    //  for getpid
#include <stdio.h>     //  for perror and printf

int main()
{
    int currentPolicy;
    pid_t pid;
    pid = getpid();
    currentPolicy = sched_getscheduler(pid);
    struct sched_param priority;
    priority.sched_priority=10;
    
    printf("SCHED_FIFO->%d \nSCHED_RR->%d \nSCHED_OTHER->%d\nsched_priority-> %d\n",SCHED_FIFO,SCHED_RR,SCHED_OTHER,priority.sched_priority); //o/p:1 2 0
    switch (currentPolicy)
    {
    case SCHED_FIFO:
        printf("Current policy is FIFO \n");
        sched_setscheduler(pid, SCHED_RR, &priority);
        currentPolicy = sched_getscheduler(pid);
        printf("Current policy is changed to %d\n", currentPolicy);
        break;
    case SCHED_RR:
        printf("Current policy is RR\n");
        sched_setscheduler(pid, SCHED_FIFO, &priority);
        currentPolicy = sched_getscheduler(pid);
        printf("Current policy is changed to %d\n", currentPolicy);
        break;
    case SCHED_OTHER:
        printf("Current policy is OTHER\n");
        sched_setscheduler(pid, SCHED_FIFO, &priority);
        currentPolicy = sched_getscheduler(pid);
        printf("Current policy is changed to %d\n", currentPolicy);// execute using sudo for seeing the changes 
        break;
    default:
        perror("Error while getting current policy\n");
    }
    return 0;
}


