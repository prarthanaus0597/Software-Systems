// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: Write a program to simulate online ticket reservation. Implement write lock. Write a program to open a file, store a ticket number and exit.


#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>


int main(int argc,char **argv,char **envi){
struct {
int ticket_no;
} db;
db.ticket_no=10;
int fd=open("db.txt",O_CREAT|O_RDWR,0744);
write(fd,&db,sizeof(db));
close(fd);
fd=open("db.txt",O_RDONLY);
read(fd,&db,sizeof(db));
printf("Ticket No. %d\n",db.ticket_no);
close(fd);
return 0;
}





