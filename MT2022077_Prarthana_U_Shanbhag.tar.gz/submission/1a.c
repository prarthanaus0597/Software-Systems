// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
//Question: Create a soft link file using the `symlink` system call

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>


int main(){
	int fd=open("source.txt",O_CREAT|O_RDWR,0777);	
	int status =symlink("source.txt","softlink.txt");
	if(status ==-1)
	perror("Error found here");
	else
	printf("\nSoftlink created\n");
	return 0;

}
