// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program, open a file, call fork, and then write to the file by both the child as well as the parent processes. Check output of the file.



#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int main(){
int fd=open("source.txt",O_CREAT|O_RDWR,0744);
int fork_val=fork();

if(fork_val==0){
write(fd,"\nChild is writing in the file\n",strlen("Child is writing in the file")+2);

}
else{
write(fd,"\nParent is writing in the file\n",strlen("Parent is writing in the file")+2);

}

return 0;
}
