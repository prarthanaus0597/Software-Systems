// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: a program to create an orphan process.


#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(){

//A process whose parent process no more exists i.e. either finished or terminated without waiting for its child process to terminate is called an orphan process.
	int fork_val=fork();
	if(fork_val>0){
		//Parent process
		sleep(5);
		printf("\nParent executing with pid:%d!!",getpid());
	}
	else if(fork_val==0)
	{
		//CHild process
		
		printf("\nBefore orphan child ppid: %d.\nPutting child process to sleep for 20 sec\n",getppid());
		sleep(20);
		printf("\nChild after orphan ...Child is awake now .Parent id is %d",getppid()); //to check ppid is systemd or not : htop -p process_id 


	}
	return 0;
}
