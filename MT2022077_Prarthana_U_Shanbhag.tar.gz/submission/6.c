// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: a program to take input from STDIN and display on STDOUT. Use only read/write system calls
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main(){
char buf[50];
read(0,buf,5);
write(1,buf,5);
return 0;
}
