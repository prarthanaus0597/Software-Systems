// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:Write a program to find the type of a file.
//	    a. Input should be taken from command line.
//	    b. program should be able to identify any type of a file.


#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>



// give the names of file in command line 
int main(int argc,char **argv){

if(argc>1){


int i=1;
while(--argc>0){
//int fd=open(argv[i],O_RDONLY);

struct stat info;
int stats =lstat(argv[i],&info);

//if(S_ISLNK(info.st_mode)) printf("link files");
//printf("%d\n",info.st_mode);

printf("%s\n",argv[i]);
i++;
//printf("%F\n",argv[i]);
//printf("File type:%d\n",info.st_mode);

 printf("File type:                ");

           switch (info.st_mode & S_IFMT) {//mask the mode to match with type
           case S_IFBLK:  printf("block device\n");            break;
           case S_IFCHR:  printf("character device\n");        break;
           case S_IFDIR:  printf("directory\n");               break;
           case S_IFIFO:  printf("FIFO/pipe\n");               break;
           case S_IFLNK:  printf("symlink\n");                 break;
           case S_IFREG:  printf("regular file\n");            break;
           case S_IFSOCK: printf("socket\n");                  break;
           default:       printf("unknown? file\n");           break;
}


}
}
else{
printf("Give the command line arguments");
}
return 0;
}
