// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: program to find out the opening mode of a file. Use fcntl.
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>



//send the file from command line 
int main(int argc,char **argv){
if(argc>2 || argc<=1){
printf("Enter only one file name as command line argument\n");

}
else{
char *arg=argv[1];
//printf("%s",arg);
int fd=open(arg,O_RDWR);

if(fd!=-1){
 printf("File Open mode:                ");
	   int val=fcntl(fd,F_GETFL,0);
           switch (val & O_ACCMODE) {//mask the mode to match with type  O_ACCMODE=011
           case O_RDONLY:  printf("Read only\n");            break; //O_RONLY=>000
           case O_WRONLY:  printf("Write only\n");             break;//O_WRONLY=>001
           case O_RDWR :  printf("Read write\n");               break;//0_RDWR=>010

           default:       printf("Error/Unknown\n");           break;
	}

close(fd);
}
else{
printf("File doesnt exist");
}

}
return 0;
}
