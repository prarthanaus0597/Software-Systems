// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: a program to execute ls -Rl by the following system calls execle()



#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

/* 

Like all of the exec functions, execle replaces the calling process image with a new process image. This has the effect of running a new progam with the process ID of the calling process. Note that a new process is not started; the new process image simply overlays the original process image. The execle function is most commonly used to overlay a process image that has been created by a call to the fork function.

int execle( const char * path,
            const char * arg0, 
            const char * arg1,
            …
            const char * argn,
            NULL,
            const char * envp[] );
This function is declared in <process.h>, which <unistd.h> includes.
 
path-The path of the file to execute.
arg0, …, argn - Pointers to NULL-terminated character strings. These strings constitute the argument list available to the new process image. You must terminate the list with a NULL pointer. The arg0 argument must point to a filename that's associated with the process being started and cannot be NULL.
envp-An array of character pointers to NULL-terminated strings. These strings constitute the environment for the new process image. Terminate the envp array with a NULL pointer.

*/



int main(){
char *command_path="/bin/ls";
char *options="-lR";
char **envp;

printf("-------------------------------Output using execle():--------------------------------------\n");
execle(command_path,command_path,options,NULL,envp);

return 0;
}
