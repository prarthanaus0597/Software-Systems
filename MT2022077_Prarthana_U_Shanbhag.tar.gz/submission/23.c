// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question: a program to create a Zombie state of the running program.
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>


int main(){

// A state where process which has finished the execution but still has entry in the process table to report to its parent process is known as a zombie state of process
	int fork_val=fork();
	if(fork_val>0){
		//Parent process
		printf("\nPutting parent process to sleep for 20 sec");
		sleep(20);
		printf("\nParent is awake now");

	}
	else{
		//CHild process
		printf("\nExiting Child Process");
		
		exit(0);

	}
	return 0;
}
