// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:  a program to find out time taken to execute getpid system call. Use time stamp counter.
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/time.h>

unsigned long long rdtsc(){

	unsigned long long dst;
	__asm__ __volatile__("rdtsc":"=A"(dst));
	return dst;
}


int main(){
	long long int start,end;
	start=rdtsc();
	int pid=getpid();
	end=rdtsc();//number of clock cycles
	printf("Difference is %llu clock cycles \n",(end-start));
	long long int time=(end-start)/2.4;
	printf("Difference is %llu ns\n",time);
	return 0;
}
