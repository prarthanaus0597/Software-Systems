// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question : Write a program to get maximum and minimum real time priority

#include <sched.h> // Import for `sched_get_priority_*` functions
#include <stdio.h> // Import for `printf`

int main()
{
    int maxPriority, minPriority;

    maxPriority = sched_get_priority_max(SCHED_RR);
    //maxPriority = sched_get_priority_max(SCHED_FIFO);
    if (maxPriority == -1)
        perror("Error while finding max priority\n");
    else
        printf("The max priority with RR Scheduling Policy is : %d\n", maxPriority);

    minPriority = sched_get_priority_min(SCHED_RR);
    //minPriority = sched_get_priority_min(SCHED_FIFO);
    if (minPriority == -1)
        perror("Error while finding min priority\n");
    else
        printf("The min priority with RR Scheduling Policy is : %d\n", minPriority);
    return 0;
}
