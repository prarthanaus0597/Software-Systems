// Name : Prarthana U Shanbhag
// Roll Number : MT2022077
// Question:a program to execute ls -Rl by the following system calls execv()

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>


/* The execv() function replaces the current process image with a new process image specified by path. The new image is constructed from a regular, executable file called the new process image file. No return is made because the calling process image is replaced by the new process image.
Syntax: 

int execv(const char *path, char *const argv[]);

path: should point to the path of the file being executed. 
argv[]: is a null terminated array of character pointers.
Let us see a small example to show how to use execv() function in C. This example is similar to the example shown above for execvp() . 

*/

int main(){
char *args[]={"/bin/ls","-lR"};

printf("-------------------------------Output using execv():--------------------------------------\n");
execv(args[0],args);

return 0;
}
